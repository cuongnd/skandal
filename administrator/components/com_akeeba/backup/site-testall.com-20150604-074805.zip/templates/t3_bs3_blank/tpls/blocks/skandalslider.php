<?php
$slider = $this->countModules('my_slider');
?>
<?php if($slider) :?>
<jdoc:include type="modules" name="my_slider" style="T3Xhtml"/>
<?php endif;?>

