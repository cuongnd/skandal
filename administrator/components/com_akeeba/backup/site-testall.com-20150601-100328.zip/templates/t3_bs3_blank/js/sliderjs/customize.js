
 $(function(){	
 
 			jQuery('#mycarouselspl').jcarousel({
				auto: 3,
				wrap: 'last',
				vertical: true,
        		scroll: 1
			});
			jQuery('#mycarousel').jcarousel({
					auto: 3,
					wrap: 'last',
					scroll: 1
			});
			
 		
		
			
});		

