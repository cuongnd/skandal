<?php
/**
 * Created by PhpStorm.
 * User: Son
 * Date: 5/25/2015
 * Time: 2:42 PM
 */
?>
<jdoc:include type="component" />